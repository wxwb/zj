# TV

> mobile = 手机版  
> leanback = 电视版

> java = jar + js 爬虫  
> python = jar + js + py 爬虫

> arm64_v8a = 64 位元  
> armeabi_v7a = 32 位元

> dev = 内测版  
> kitkat = 4.x 版  
> release = 正式版
